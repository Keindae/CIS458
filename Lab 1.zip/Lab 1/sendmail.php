<html>
<body>
<h1>Send Phising Emails</h1>
<?php
mail('noblettm@mail.gvsu.edu', 'Your account is hacked', 'Please call us',
    'From: turmp@whitehouse.gov');
?>

</body>

</html>
